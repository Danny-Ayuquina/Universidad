﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos_Lineas
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void CerrarFormulariosHijos()
        {
            foreach (Form frm in this.MdiChildren)
            {
                frm.Close();
            }
        }

        private void dDAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            FrmDDA frmDDA = new FrmDDA();
            frmDDA.MdiParent = this;
            frmDDA.Dock = DockStyle.Fill;
            frmDDA.Show();
        }

        private void bresenhamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            FrmBresenham frmBresenham = new FrmBresenham();
            frmBresenham.MdiParent = this;
            frmBresenham.Dock = DockStyle.Fill;
            frmBresenham.Show();
        }

        private void puntoMedioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            FrmPuntoMedio frmPuntoMedio = new FrmPuntoMedio();
            frmPuntoMedio.MdiParent = this;
            frmPuntoMedio.Dock = DockStyle.Fill;
            frmPuntoMedio.Show();
        }
    }
}
